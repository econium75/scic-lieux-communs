Export opération Orly Ecohome
Code : ORLY-ECO-2027
Commune : Orly (94)
Généré le : 2026-10-10T12:40:28.847362Z
Scénarios inclus : 1

Contenu :
- scenarios/<id>_<nom>/bilan.xlsx — bilan M2
- scenarios/<id>_<nom>/exploitation.xlsx — exploitation M3 (si configurée)
- scenarios/<id>_<nom>/commercialisation.xlsx — ménages M4
- scenarios/<id>_<nom>/synthese.pdf — PDF de synthèse comité d'engagement
- pieces_jointes/ — toutes les pièces jointes de l'opération et ses phases
